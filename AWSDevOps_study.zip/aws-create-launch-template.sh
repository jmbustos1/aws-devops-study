aws ec2 create-launch-template \
    --launch-template-name my-launch-template \
    --version-description "Initial version" \
    --launch-template-data '{
        "ImageId":"ami-005fc0f236362e99f",
        "InstanceType":"t2.micro",
        "KeyName":"aws-eb",
        "SecurityGroupIds":["sg-08c6afcf06c5972ed"],
        "TagSpecifications":[
            {
                "ResourceType":"instance",
                "Tags":[
                    {"Key":"Name","Value":"MyAutoScalingInstance"}
                ]
            }
        ]
    }' \
