aws autoscaling create-auto-scaling-group \
  --auto-scaling-group-name my-auto-scaling-group \
  --launch-template LaunchTemplateId=lt-0f742817de78b6ab8,Version=1 \
  --min-size 1 \
  --max-size 3 \
  --desired-capacity 1 \
  --vpc-zone-identifier "subnet-0f0ab1a14c765d86b,subnet-06dd51d240ef0b4fe,subnet-07b3203db92bd4e73" \
  --region us-east-1
